<?php

    $filename = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']); // getting file name from current URL
?>

<nav class="col-md-2 d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "dashboard.php") { ?> active <?php }  ?>"
                    href="dashboard.php">
                    <span data-feather="home"></span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "coursera.php") { ?> active <?php }  ?>"
                    href="coursera.php">
                    <span data-feather="file"></span>
                    Coursera
                </a>
            </li>

             <li class="nav-item">
                <a class="nav-link <?php if ($filename == "udemy.php") { ?> active <?php }  ?>"
                    href="udemy.php">
                    <span data-feather="file"></span>
                    Udemy
                </a>
            </li>

        </ul>


    </div>
</nav>