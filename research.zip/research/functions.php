<?php

    include('db_connection.php');

    //dataType to check if there's some value inside it or not
    if (isset($_POST['dataType'])) {
         //$url = "http://127.0.0.1:5000/courses";
        $url = "http://127.0.0.1:5000/".$_POST['dataType']; //API
        // $url = "http://127.0.0.1:5000/women_cloths";
        $data = file_get_contents($url); //all data of python

        $res = json_decode(mb_convert_encoding($data,'UTF-8','UTF-8'), true); //convert string data into json

        // inserting in table
        $temp = $res['list'];
        for ($i=0; $i < count($temp); $i++) {
            for ($j=0; $j < count($temp[$i]); $j++) {
                $Uname = addslashes($temp[$i][$j]['Uname']);
                $Cname = addslashes($temp[$i][$j]['Cname']);
                $description = addslashes($temp[$i][$j]['description']);
                $image = addslashes($temp[$i][$j]['image']);
                $link = addslashes($temp[$i][$j]['href']);


                // $sql = "INSERT INTO  women_cloths (title, price, image, brand)
                $sql = "INSERT INTO  ".$_POST['dataType']." (Uname, Cname, description,  image, link)
                VALUES ('".$Uname."', '".$Cname."', '".$description."' , '".$image."', '".$link."')";


                if ($con->query($sql) === TRUE) {
                    echo "New record created successfully";

                } else {
                     echo "Error: " . $sql . "<br>" . $con->error;
                }

            }
        }

        $con->close();
        echo $data;
    }

//      $temp = $res['list'];
//         for ($i=0; $i < count($temp); $i++) {
//             for ($j=0; $j < count($temp[$i]); $j++) {
//                 $Uname = addslashes($temp[$i][$j]['Uname']);
//                 $Cname = addslashes($temp[$i][$j]['Cname']);
//                 $description = addslashes($temp[$i][$j]['description']);
//                 $image = addslashes($temp[$i][$j]['image']);
//
//                 $sql = "INSERT INTO  cousera (Uname, Cname, description, image)
//                 VALUES ('".$Uname."', '".$Cname."', '".$description."', '".$image."')";
//
//                 if ($con->query($sql) === TRUE) {
//                     // echo "New record created successfully";
//                 } else {
//                     // echo "Error: " . $sql . "<br>" . $con->error;
//                 }
//
//             }
//         }

    // Delete Data

    if (isset($_POST['dataDeleteType'])) {
        $sql = "TRUNCATE TABLE  ".$_POST['dataDeleteType']." ";
        if ($con->query($sql) === TRUE) {
            echo "Table Cleared successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $con->error;
        }
    }

?>