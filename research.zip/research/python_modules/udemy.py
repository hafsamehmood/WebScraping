import requests
from bs4 import BeautifulSoup

headers = {
    "User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}


def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False


def udemy():
    url = "https://www.udemy.com/courses/search/?src=ukw&q=data+structures"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_uname = soup.select('.course-card--instructor-list--nH1OC')
    sc_cname = soup.select(".udlite-heading-md course-card--course-title--vVEjC")
    sc_description = soup.select(".udlite-text-sm course-card--course-headline--2DAqq")
    sc_img = soup.select(".course-card--image-wrapper--1F9ny")


    liste = []
    for index in range(len(sc_cname)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_cname[index]['href'], "https") or findString(sc_cname[index]['href'], "http"):
            link = sc_cname[index]['href']
        else:

            link = "https://www.udemy.com/" + sc_cname[index]['href']

        liste.append(
            {
                'Uname': sc_uname[index].get_text().strip(),
                'Cname': sc_cname[index].get_text().strip(),
                'description': sc_description[index].get_text().strip(),
                'image': img,
                'href': link
            }
        )
    # print(liste)
    return liste

# Hopscotch()

def getUdemy():
    return [udemy()]