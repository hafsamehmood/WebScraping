import requests
from bs4 import BeautifulSoup

headers = {
    "User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}


def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False


def cousera():

    url = "https://www.coursera.org/search?query=data%20structures&"

    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_uname = soup.select('.cds-33 css-14d8ngk cds-35')
    sc_cname = soup.select(".cds-33 css-bku0rr cds-35")
    sc_description = soup.select(".css-1qajodb")
    sc_img = soup.select(".css-1doy6bd")


    liste = []
    for index in range(len(sc_cname)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_cname[index]['href'], "https") or findString(sc_cname[index]['href'], "http"):
            link = sc_cname[index]['href']
        else:

            link = "https://www.coursera.org/" + sc_cname[index]['href']

        liste.append(
            {
                'Uname': sc_uname[index].get_text().strip(),
                'Cname': sc_cname[index].get_text().strip(),
                'description': sc_description[index].get_text().strip(),
                'image': img,
                'href': link
            }
        )
    print(liste)
    return liste


def getCourses():
    return [cousera()]